package PROJECT_FINAL;

import Components.PetriNet;
import Components.Activation;
import Components.Condition;
import Components.GuardMapping;
import Components.PetriNet;
import Components.PetriNetWindow;
import Components.PetriTransition;
import DataObjects.DataCar;
import DataObjects.DataCarQueue;
import DataObjects.DataString;
import DataObjects.DataTransfer;
import DataOnly.TransferOperation;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

public class Lanes_Intersection_Bucharest {

    public static void main(String[] args) {

        PetriNet pn = new PetriNet();
        pn.PetriNetName = "Lanes Intersection Bucharest";
        pn.NetworkPort = 1080;

        // -------------------------------------------------------------------
        // --------------------CALEA FERENTARI SECTION 1----------------------
        // -------------------------------------------------------------------

        //------------------VEST--------------------------
        //-------------------IN---------------------------
        DataCar P_LaneIn_S1 = new DataCar();
        P_LaneIn_S1.SetName("P_LaneIn_S1");
        pn.PlaceList.add(P_LaneIn_S1);

        DataCar P_Lane_DunuvatIn_V_S1 = new DataCar();
        P_Lane_DunuvatIn_V_S1.SetName("P_Lane_DunuvatIn_V_S1");
        pn.PlaceList.add(P_Lane_DunuvatIn_V_S1);

        DataCar P_Lane_DunuvatIn2_V_S1 = new DataCar();
        P_Lane_DunuvatIn2_V_S1.SetName("P_Lane_DunuvatIn2_V_S1");
        pn.PlaceList.add(P_Lane_DunuvatIn2_V_S1);

        //----------------------------T1----------------------------------------


        DataCarQueue P_LaneIn_int1_V_S1 = new DataCarQueue();
        P_LaneIn_int1_V_S1.Value.Size = 3;
        P_LaneIn_int1_V_S1.SetName("P_LaneIn_int1_V_S1");
        pn.PlaceList.add(P_LaneIn_int1_V_S1);

        DataCar P_Lane_TelitaOut_V_S1 = new DataCar();
        P_Lane_TelitaOut_V_S1.SetName("P_Lane_TelitaOut_V_S1");
        pn.PlaceList.add(P_Lane_TelitaOut_V_S1);

        DataCar P_Lane_TelitaIn_V_S1 = new DataCar();
        P_Lane_TelitaIn_V_S1.SetName("P_Lane_TelitaIn_V_S1");
        pn.PlaceList.add(P_Lane_TelitaIn_V_S1);

        DataCarQueue P_LaneIn_int2_V_S1 = new DataCarQueue();
        P_LaneIn_int2_V_S1.SetName("P_LaneIn_int2_V_S1");
        P_LaneIn_int2_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneIn_int2_V_S1);

        DataCarQueue P_LaneIn_int3_V_S1 = new DataCarQueue();
        P_LaneIn_int3_V_S1.Value.Size = 3;
        P_LaneIn_int3_V_S1.SetName("P_LaneIn_int3_V_S1");
        pn.PlaceList.add(P_LaneIn_int3_V_S1);

        DataCarQueue P_LaneIn_int4_V_S1 = new DataCarQueue();
        P_LaneIn_int4_V_S1.Value.Size = 3;
        P_LaneIn_int4_V_S1.SetName("P_LaneIn_int4_V_S1");
        pn.PlaceList.add(P_LaneIn_int4_V_S1);

        DataCar P_LaneInOut_V_S1 = new DataCar();
        P_LaneInOut_V_S1.SetName("P_LaneInOut_V_S1");
        pn.PlaceList.add(P_LaneInOut_V_S1);

        DataCarQueue P_LaneIn_int5_V_S1 = new DataCarQueue();
        P_LaneIn_int5_V_S1.Value.Size = 4;
        P_LaneIn_int5_V_S1.SetName("P_LaneIn_int5_V_S1");
        pn.PlaceList.add(P_LaneIn_int5_V_S1);

        DataCarQueue P_x_Lane_V_S1 = new DataCarQueue();
        P_x_Lane_V_S1.Value.Size = 4;
        P_x_Lane_V_S1.SetName("P_x_Lane_V_S1");
        pn.PlaceList.add(P_x_Lane_V_S1);

        DataCar P_b_Lane_V_S1 = new DataCar();
        P_b_Lane_V_S1.SetName("P_b_Lane_V_S1");
        pn.PlaceList.add(P_b_Lane_V_S1);

        //-------------------OUT---------------------------
        DataCar P_LaneOut_V_S1 = new DataCar();
        P_LaneOut_V_S1.SetName("P_LaneOut_V_S1");
        pn.PlaceList.add(P_LaneOut_V_S1);

        DataCarQueue P_LaneOut_Int1_V_S1 = new DataCarQueue();
        P_LaneOut_Int1_V_S1.SetName("P_LaneOut_Int1_V_S1");
        P_LaneOut_Int1_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int1_V_S1);

        DataCar P_LaneDonici_V_In_S1 = new DataCar();
        P_LaneDonici_V_In_S1.SetName("P_LaneDonici_V_In_S1");
        pn.PlaceList.add(P_LaneDonici_V_In_S1);

        //----------------------------T1_V_S1----------------------------------------
        PetriTransition T1_Out_V_S1 = new PetriTransition(pn);
        T1_Out_V_S1.TransitionName = "T1_Out_V_S1";
        T1_Out_V_S1.InputPlaceName.add("P_LaneOut_Int1_V_S1");
        T1_Out_V_S1.InputPlaceName.add("P_LaneDonici_V_In_S1");

        // --------------guard 1-------------------------------------------------------
        Condition T1_Out_V_S1_Ct11 = new Condition(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionCondition.HaveCar);
        Condition T1_Out_V_S1_Ct12 = new Condition(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionCondition.IsNull);
        T1_Out_V_S1_Ct11.SetNextCondition(LogicConnector.AND, T1_Out_V_S1_Ct12);
        GuardMapping grd1T1_Out_V_S1 = new GuardMapping();
        grd1T1_Out_V_S1.condition = T1_Out_V_S1_Ct11;
        grd1T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionOperation.PopElementWithoutTarget, "P_LaneOut_V_S1"));
        T1_Out_V_S1.GuardMappingList.add(grd1T1_Out_V_S1);

        // --------------guard 2-------------------------------------------------------
        Condition T1_Out_V_S1_Ct21 = new Condition(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionCondition.IsNull);
        Condition T1_Out_V_S1_Ct22 = new Condition(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionCondition.NotNull);
        T1_Out_V_S1_Ct21.SetNextCondition(LogicConnector.AND, T1_Out_V_S1_Ct22);
        GuardMapping grd2T1_Out_V_S1 = new GuardMapping();
        grd2T1_Out_V_S1.condition = T1_Out_V_S1_Ct21;
        grd2T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionOperation.Move, "P_LaneOut_V_S1"));
        T1_Out_V_S1.GuardMappingList.add(grd2T1_Out_V_S1);

        // --------------guard 4-------------------------------------------------------
        Condition T1_Out_V_S1_Ct41 = new Condition(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionCondition.HaveCar);
        Condition T1_Out_V_S1_Ct42 = new Condition(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionCondition.IsPriorityCar);
        T1_Out_V_S1_Ct41.SetNextCondition(LogicConnector.AND, T1_Out_V_S1_Ct42);
        GuardMapping grd4T1_Out_V_S1 = new GuardMapping();
        grd4T1_Out_V_S1.condition = T1_Out_V_S1_Ct41;
        grd4T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionOperation.Move, "P_LaneOut_V_S1"));
        grd4T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionOperation.PopElementWithoutTarget, "P_LaneOut_V_S1"));
        T1_Out_V_S1.GuardMappingList.add(grd4T1_Out_V_S1);

        // ----------------------------------------------------------------------------
        Condition T1_Out_V_S1_Ct51 = new Condition(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionCondition.IsPriorityCar);

        GuardMapping grd5T1_Out_V_S1 = new GuardMapping();
        grd5T1_Out_V_S1.condition = T1_Out_V_S1_Ct51;
        grd5T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionOperation.Move, "P_LaneOut_V_S1"));
        T1_Out_V_S1.GuardMappingList.add(grd5T1_Out_V_S1);


        // --------------guard 3-------------------------------------------------------
        Condition T1_Out_V_S1_Ct31 = new Condition(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionCondition.HaveCar);
        Condition T1_Out_V_S1_Ct32 = new Condition(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionCondition.NotNull);
        T1_Out_V_S1_Ct31.SetNextCondition(LogicConnector.AND, T1_Out_V_S1_Ct32);
        GuardMapping grd3T1_Out_V_S1 = new GuardMapping();
        grd3T1_Out_V_S1.condition = T1_Out_V_S1_Ct31;
        grd3T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneOut_Int1_V_S1", TransitionOperation.PopElementWithoutTarget, "P_LaneOut_V_S1"));
        grd3T1_Out_V_S1.Activations.add(new Activation(T1_Out_V_S1, "P_LaneDonici_V_In_S1", TransitionOperation.Move, "P_LaneOut_V_S1"));
        T1_Out_V_S1.GuardMappingList.add(grd3T1_Out_V_S1);

        T1_Out_V_S1.Delay = 0;
        pn.Transitions.add(T1_Out_V_S1);


        DataCar P_LaneDonici_V_Out_S1 = new DataCar();
        P_LaneDonici_V_Out_S1.SetName("P_LaneDonici_V_Out_S1");
        pn.PlaceList.add(P_LaneDonici_V_Out_S1);

        DataCarQueue P_LaneOut_Int2_V_S1 = new DataCarQueue();
        P_LaneOut_Int2_V_S1.SetName("P_LaneOut_Int2_V_S1");
        P_LaneOut_Int2_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int2_V_S1);

        DataCarQueue P_LaneOut_Int3_V_S1 = new DataCarQueue();
        P_LaneOut_Int3_V_S1.SetName("P_LaneOut_Int3_V_S1");
        P_LaneOut_Int3_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int3_V_S1);

        DataCar P_LaneGhDonici_V_In_S1 = new DataCar();
        P_LaneGhDonici_V_In_S1.SetName("P_LaneGhDonici_V_In_S1");
        pn.PlaceList.add(P_LaneGhDonici_V_In_S1);

        DataCar P_LaneGhDonici_V_Out_S1 = new DataCar();
        P_LaneGhDonici_V_Out_S1.SetName("P_LaneGhDonici_V_Out_S1");
        pn.PlaceList.add(P_LaneGhDonici_V_Out_S1);

        DataCarQueue P_LaneOut_Int4_V_S1 = new DataCarQueue();
        P_LaneOut_Int4_V_S1.SetName("P_LaneOut_Int4_V_S1");
        P_LaneOut_Int4_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int4_V_S1);

        DataCarQueue P_LaneOut_Int5_V_S1 = new DataCarQueue();
        P_LaneOut_Int5_V_S1.SetName("P_LaneOut_Int5_V_S1");
        P_LaneOut_Int5_V_S1.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int5_V_S1);

        DataCarQueue P_BusStation_Sebastian_V_Out_S1 = new DataCarQueue();
        P_BusStation_Sebastian_V_Out_S1.SetName("P_BusStation_Sebastian_V_Out_S1");
        P_BusStation_Sebastian_V_Out_S1.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_Sebastian_V_Out_S1);

        DataCarQueue P_BusStation_Sebastian_V_S1 = new DataCarQueue();
        P_BusStation_Sebastian_V_S1.SetName("P_BusStation_Sebastian_V_S1");
        P_BusStation_Sebastian_V_S1.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_Sebastian_V_S1);

        DataCarQueue P_O_Lane_V_S1 = new DataCarQueue();
        P_O_Lane_V_S1.Value.Size = 3;
        P_O_Lane_V_S1.SetName("P_O_Lane_V_S1");
        pn.PlaceList.add(P_O_Lane_V_S1);

        //------------------NORTH--------------------------
        //-------------------IN---------------------------
        DataCar P_LaneIn_N_S1   = new DataCar();
        P_LaneIn_N_S1.SetName("P_LaneIn_N_S1");
        pn.PlaceList.add(P_LaneIn_N_S1);

        DataCarQueue P_x_Lane_N_S1 = new DataCarQueue();
        P_x_Lane_N_S1.Value.Size = 3;
        P_x_Lane_N_S1.SetName("P_x_Lane_N_S1");
        pn.PlaceList.add(P_x_Lane_N_S1);

        DataCar P_b_Lane_N_S1   = new DataCar();
        P_b_Lane_N_S1.SetName("P_b_Lane_N_S1");
        pn.PlaceList.add(P_b_Lane_N_S1);

        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_N_S1 = new DataCarQueue();
        P_O_Lane_N_S1.Value.Size = 3;
        P_O_Lane_N_S1.SetName("P_O_Lane_N_S1");
        pn.PlaceList.add(P_O_Lane_N_S1);

        DataCar P_Oe_Lane_N_S1 = new DataCar();
        P_Oe_Lane_N_S1.SetName("P_Oe_Lane_N_S1");
        pn.PlaceList.add(P_Oe_Lane_N_S1);


        //------------------SOUTH--------------------------
        //-------------------IN---------------------------
        DataCar P_LaneIn_int1_S_S1 = new DataCar();
        P_LaneIn_int1_S_S1.SetName("P_LaneIn_int1_S_S1");
        pn.PlaceList.add(P_LaneIn_int1_S_S1);

        DataCarQueue P_x_Lane_S_S1 = new DataCarQueue();
        P_x_Lane_S_S1.Value.Size = 6;
        P_x_Lane_S_S1.SetName("P_x_Lane_S_S1");
        pn.PlaceList.add(P_x_Lane_S_S1);

        DataCar P_b_Lane_S_S1 = new DataCar();
        P_b_Lane_S_S1.SetName("P_b_Lane_S_S1");
        pn.PlaceList.add(P_b_Lane_S_S1);

        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_S_S1 = new DataCarQueue();
        P_O_Lane_S_S1.Value.Size = 4;
        P_O_Lane_S_S1.SetName("P_O_Lane_S_S1");
        pn.PlaceList.add(P_O_Lane_S_S1);

        DataCar P_Oe_Lane_S_S1 = new DataCar();
        P_Oe_Lane_S_S1.SetName("P_Oe_Lane_S_S1");
        pn.PlaceList.add(P_Oe_Lane_S_S1);

        //------------------EAST--------------------------
        //-------------------IN---------------------------
        DataCarQueue P_x_Lane_E_S1 = new DataCarQueue();
        P_x_Lane_E_S1.Value.Size = 3;
        P_x_Lane_E_S1.SetName("P_x_Lane_E_S1");
        pn.PlaceList.add(P_x_Lane_E_S1);

        DataCar P_b_Lane_E_S1 = new DataCar();
        P_b_Lane_E_S1.SetName("P_b_Lane_E_S1");
        pn.PlaceList.add(P_b_Lane_E_S1);


        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_E_S1 = new DataCarQueue();
        P_O_Lane_E_S1.Value.Size = 3;
        P_O_Lane_E_S1.SetName("P_O_Lane_E_S1");
        pn.PlaceList.add(P_O_Lane_E_S1);

        //-------------------INTERSECTION---------------------------
        DataCarQueue P_I_S1 = new DataCarQueue();
        P_I_S1.Value.Size = 3;
        P_I_S1.SetName("P_I_S1");
        pn.PlaceList.add(P_I_S1);

        //-------------------SEMAPHORES---------------------------
        //-------------------VEST---------------------------
        DataString P_TL_V_S1 = new DataString();
        P_TL_V_S1.SetName("P_TL_V_S1");
        pn.PlaceList.add(P_TL_V_S1);

        DataString P_PTL_V_S1 = new DataString();
        P_PTL_V_S1.SetName("P_PTL_V_S1");
        pn.PlaceList.add(P_PTL_V_S1);

        DataString UserReq_V_S1 = new DataString();
        UserReq_V_S1.SetName("UserReq_V_S1");
        pn.PlaceList.add(UserReq_V_S1);

        DataTransfer OP_Req_V_S1 = new DataTransfer();
        OP_Req_V_S1.SetName("OP_Req_V_S1");
        OP_Req_V_S1.Value = new TransferOperation("localhost", "1081" , "UserReq_V");
        pn.PlaceList.add(OP_Req_V_S1);

        //-------------------NORTH---------------------------
        DataString P_TL_N_S1 = new DataString();
        P_TL_N_S1.SetName("P_TL_N_S1");
        pn.PlaceList.add(P_TL_N_S1);

        DataString P_PTL_N_S1 = new DataString();
        P_PTL_N_S1.SetName("P_PTL_N_S1");
        pn.PlaceList.add(P_PTL_N_S1);

        DataString UserReq_N_S1 = new DataString();
        UserReq_N_S1.SetName("UserReq_N_S1");
        pn.PlaceList.add(UserReq_N_S1);

        DataTransfer OP_Req_N_S1 = new DataTransfer();
        OP_Req_N_S1.SetName("OP_Req_N_S1");
        OP_Req_N_S1.Value = new TransferOperation("localhost", "1081" , "UserReq_N");
        pn.PlaceList.add(OP_Req_N_S1);

        //-------------------SOUTH---------------------------
        DataString P_TL_S_S1 = new DataString();
        P_TL_S_S1.SetName("P_TL_S_S1");
        pn.PlaceList.add(P_TL_S_S1);

        DataString P_PTL_S_S1 = new DataString();
        P_PTL_S_S1.SetName("P_PTL_S_S1");
        pn.PlaceList.add(P_PTL_S_S1);

        DataString UserReq_S_S1 = new DataString();
        UserReq_S_S1.SetName("UserReq_S_S1");
        pn.PlaceList.add(UserReq_S_S1);

        DataTransfer OP_Req_S_S1 = new DataTransfer();
        OP_Req_S_S1.SetName("OP_Req_S_S1");
        OP_Req_S_S1.Value = new TransferOperation("localhost", "1081" , "UserReq_S");
        pn.PlaceList.add(OP_Req_S_S1);

        //-------------------EAST---------------------------
        DataString P_TL_E_S1 = new DataString();
        P_TL_E_S1.SetName("P_TL_E_S1");
        pn.PlaceList.add(P_TL_E_S1);

        DataString P_PTL_E_S1 = new DataString();
        P_PTL_E_S1.SetName("P_PTL_E_S1");
        pn.PlaceList.add(P_PTL_E_S1);

        DataString UserReq_E_S1 = new DataString();
        UserReq_E_S1.SetName("UserReq_E_S1");
        pn.PlaceList.add(UserReq_E_S1);

        DataTransfer OP_Req_E_S1 = new DataTransfer();
        OP_Req_E_S1.SetName("OP_Req_E_S1");
        OP_Req_E_S1.Value = new TransferOperation("localhost", "1081" , "UserReq_E");
        pn.PlaceList.add(OP_Req_E_S1);

        // -------------------------------------------------------------------
        // ----------------END CALEA FERENTARI SECTION 1----------------------
        // -------------------------------------------------------------------

        // -------------------------------------------------------------------
        // --------------------CALEA FERENTARI SECTION 2----------------------
        // -------------------------------------------------------------------

        //------------------VEST--------------------------
        //-------------------IN---------------------------
        DataCarQueue P_LaneIn_int1_V_S2 = new DataCarQueue();
        P_LaneIn_int1_V_S2.Value.Size = 3;
        P_LaneIn_int1_V_S2.SetName("P_LaneIn_int1_V_S2");
        pn.PlaceList.add(P_LaneIn_int1_V_S2);

        DataCarQueue P_LaneIn_int2_V_S2 = new DataCarQueue();
        P_LaneIn_int2_V_S2.Value.Size = 2;
        P_LaneIn_int2_V_S2.SetName("P_LaneIn_int2_V_S2");
        pn.PlaceList.add(P_LaneIn_int2_V_S2);

        DataCar P_Lane_LocusteanuOut_V_S2 = new DataCar();
        P_Lane_LocusteanuOut_V_S2.SetName("P_Lane_LocusteanuOut_V_S2");
        pn.PlaceList.add(P_Lane_LocusteanuOut_V_S2);

        DataCar P_Lane_LocusteanuIn_V_S2 = new DataCar();
        P_Lane_LocusteanuIn_V_S2.SetName("P_Lane_LocusteanuIn_V_S2");
        pn.PlaceList.add(P_Lane_LocusteanuIn_V_S2);

        DataCarQueue P_LaneIn_int3_V_S2 = new DataCarQueue();
        P_LaneIn_int3_V_S2.Value.Size = 3;
        P_LaneIn_int3_V_S2.SetName("P_LaneIn_int3_V_S2");
        pn.PlaceList.add(P_LaneIn_int3_V_S2);

        DataCarQueue P_TramStationIn_CaleaFerentari_V_S2 = new DataCarQueue();
        P_TramStationIn_CaleaFerentari_V_S2.Value.Size = 1;
        P_TramStationIn_CaleaFerentari_V_S2.SetName("P_TramStationIn_CaleaFerentari_V_S2");
        pn.PlaceList.add(P_TramStationIn_CaleaFerentari_V_S2);

        DataCarQueue P_TramStationIn_CaleaFerentariOut_V_S2 = new DataCarQueue();
        P_TramStationIn_CaleaFerentariOut_V_S2.Value.Size = 1;
        P_TramStationIn_CaleaFerentariOut_V_S2.SetName("P_TramStationIn_CaleaFerentariOut_V_S2");
        pn.PlaceList.add(P_TramStationIn_CaleaFerentariOut_V_S2);

        DataCarQueue P_LaneIn_int4_V_S2 = new DataCarQueue();
        P_LaneIn_int4_V_S2.Value.Size = 3;
        P_LaneIn_int4_V_S2.SetName("P_LaneIn_int4_V_S2");
        pn.PlaceList.add(P_LaneIn_int4_V_S2);

        DataCarQueue P_BusStation_CaleaRahovei_V_S2 = new DataCarQueue();
        P_BusStation_CaleaRahovei_V_S2.Value.Size = 2;
        P_BusStation_CaleaRahovei_V_S2.SetName("P_BusStation_CaleaRahovei_V_S2");
        pn.PlaceList.add(P_BusStation_CaleaRahovei_V_S2);

        DataCarQueue P_BusStation_CaleaRahoveiOut_V_S2 = new DataCarQueue();
        P_BusStation_CaleaRahoveiOut_V_S2.Value.Size = 2;
        P_BusStation_CaleaRahoveiOut_V_S2.SetName("P_BusStation_CaleaRahoveiOut_V_S2");
        pn.PlaceList.add(P_BusStation_CaleaRahoveiOut_V_S2);

        DataCarQueue P_LaneIn_int5_V_S2 = new DataCarQueue();
        P_LaneIn_int5_V_S2.Value.Size = 3;
        P_LaneIn_int5_V_S2.SetName("P_LaneIn_int5_V_S2");
        pn.PlaceList.add(P_LaneIn_int5_V_S2);

        DataCarQueue P_LaneIn_int6_V_S2 = new DataCarQueue();
        P_LaneIn_int6_V_S2.Value.Size = 3;
        P_LaneIn_int6_V_S2.SetName("P_LaneIn_int6_V_S2");
        pn.PlaceList.add(P_LaneIn_int6_V_S2);

        DataCar P_Lane_OlaruOut_V_S2 = new DataCar();
        P_Lane_OlaruOut_V_S2.SetName("P_Lane_OlaruOut_V_S2");
        pn.PlaceList.add(P_Lane_OlaruOut_V_S2);

        DataCar P_Lane_OlaruIn_V_S2 = new DataCar();
        P_Lane_OlaruIn_V_S2.SetName("P_Lane_OlaruIn_V_S2");
        pn.PlaceList.add(P_Lane_OlaruIn_V_S2);

        DataCarQueue P_LaneIn_int7_V_S2 = new DataCarQueue();
        P_LaneIn_int7_V_S2.Value.Size = 3;
        P_LaneIn_int7_V_S2.SetName("P_LaneIn_int7_V_S2");
        pn.PlaceList.add(P_LaneIn_int7_V_S2);


        //-------------------OUT--------------------------
        DataCarQueue P_LaneOut_Int1_V_S2 = new DataCarQueue();
        P_LaneOut_Int1_V_S2.SetName("P_LaneOut_Int1_V_S2");
        P_LaneOut_Int1_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int1_V_S2);

        DataCar P_Lane_TocilescuIn_V_S2 = new DataCar();
        P_Lane_TocilescuIn_V_S2.SetName("P_Lane_TocilescuIn_V_S2");
        pn.PlaceList.add(P_Lane_TocilescuIn_V_S2);

        DataCar P_Lane_TocilescuOut_V_S2 = new DataCar();
        P_Lane_TocilescuOut_V_S2.SetName("P_Lane_TocilescuOut_V_S2");
        pn.PlaceList.add(P_Lane_TocilescuOut_V_S2);

        DataCarQueue P_LaneOut_Int2_V_S2 = new DataCarQueue();
        P_LaneOut_Int2_V_S2.Value.Size = 2;
        P_LaneOut_Int2_V_S2.SetName("P_LaneOut_Int2_V_S2");
        pn.PlaceList.add(P_LaneOut_Int2_V_S2);

        DataCarQueue P_TramStationOut_CaleaFerentari_V_Out_S2 = new DataCarQueue();
        P_TramStationOut_CaleaFerentari_V_Out_S2.SetName("P_TramStationOut_CaleaFerentari_V_Out_S2");
        P_TramStationOut_CaleaFerentari_V_Out_S2.Value.Size = 1;
        pn.PlaceList.add(P_TramStationOut_CaleaFerentari_V_Out_S2);

        DataCarQueue P_TramStationOut_CaleaFerentari_V_S2 = new DataCarQueue();
        P_TramStationOut_CaleaFerentari_V_S2.SetName("P_TramStationOut_CaleaFerentari_V_S2");
        P_TramStationOut_CaleaFerentari_V_S2.Value.Size = 1;
        pn.PlaceList.add(P_TramStationOut_CaleaFerentari_V_S2);

        DataCarQueue P_LaneOut_Int3_V_S2 = new DataCarQueue();
        P_LaneOut_Int3_V_S2.SetName("P_LaneOut_Int3_V_S2");
        P_LaneOut_Int3_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int3_V_S2);

        DataCar P_Lane_PoenaruIn_V_S2 = new DataCar();
        P_Lane_PoenaruIn_V_S2.SetName("P_Lane_PoenaruIn_V_S2");
        pn.PlaceList.add(P_Lane_PoenaruIn_V_S2);

        DataCar P_Lane_PoenaruIn2_V_S2 = new DataCar();
        P_Lane_PoenaruIn2_V_S2.SetName("P_Lane_PoenaruIn2_V_S2");
        pn.PlaceList.add(P_Lane_PoenaruIn2_V_S2);

        DataCarQueue P_LaneOut_Int4_V_S2 = new DataCarQueue();
        P_LaneOut_Int4_V_S2.SetName("P_LaneOut_Int4_V_S2");
        P_LaneOut_Int4_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int4_V_S2);

        DataCar P_Lane_LidlIn_V_S2 = new DataCar();
        P_Lane_LidlIn_V_S2.SetName("P_Lane_LidlIn_V_S2");
        pn.PlaceList.add(P_Lane_LidlIn_V_S2);

        DataCar P_Lane_LidlOut_V_S2 = new DataCar();
        P_Lane_LidlOut_V_S2.SetName("P_Lane_LidlOut_V_S2");
        pn.PlaceList.add(P_Lane_LidlOut_V_S2);

        DataCarQueue P_LaneOut_Int5_V_S2 = new DataCarQueue();
        P_LaneOut_Int5_V_S2.SetName("P_LaneOut_Int5_V_S2");
        P_LaneOut_Int5_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int5_V_S2);

        DataCarQueue P_LaneOut_Int6_V_S2 = new DataCarQueue();
        P_LaneOut_Int6_V_S2.SetName("P_LaneOut_Int6_V_S2");
        P_LaneOut_Int6_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int6_V_S2);

        DataCar P_Lane_BenzinarieIn_V_S2 = new DataCar();
        P_Lane_BenzinarieIn_V_S2.SetName("P_Lane_BenzinarieIn_V_S2");
        pn.PlaceList.add(P_Lane_BenzinarieIn_V_S2);

        DataCar P_Lane_BenzinarieOut_V_S2 = new DataCar();
        P_Lane_BenzinarieOut_V_S2.SetName("P_Lane_BenzinarieOut_V_S2");
        pn.PlaceList.add(P_Lane_BenzinarieOut_V_S2);

        DataCarQueue P_LaneOut_Int7_V_S2 = new DataCarQueue();
        P_LaneOut_Int7_V_S2.SetName("P_LaneOut_Int7_V_S2");
        P_LaneOut_Int7_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int7_V_S2);

        DataCarQueue P_LaneOut_Int8_V_S2 = new DataCarQueue();
        P_LaneOut_Int8_V_S2.SetName("P_LaneOut_Int8_V_S2");
        P_LaneOut_Int8_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int8_V_S2);


        //-------------------CROSSING----------------------------------------
        DataCarQueue P_x_Cross_Lane_V_Out_S2 = new DataCarQueue();
        P_x_Cross_Lane_V_Out_S2.Value.Size = 3;
        P_x_Cross_Lane_V_Out_S2.SetName("P_x_Cross_Lane_V_Out_S2");
        pn.PlaceList.add(P_x_Cross_Lane_V_Out_S2);

        DataCarQueue P_x_Cross_Lane_V_In_S2 = new DataCarQueue();
        P_x_Cross_Lane_V_In_S2.Value.Size = 3;
        P_x_Cross_Lane_V_In_S2.SetName("P_x_Cross_Lane_V_In_S2");
        pn.PlaceList.add(P_x_Cross_Lane_V_In_S2);

        DataString P_Cross_TL_V_S2 = new DataString();
        P_Cross_TL_V_S2.SetName("P_Cross_TL_V_S2");
        pn.PlaceList.add(P_Cross_TL_V_S2);

        DataString P_Cross_PTL_V_S2 = new DataString();
        P_Cross_PTL_V_S2.SetName("P_Cross_PTL_V_S2");
        pn.PlaceList.add(P_Cross_PTL_V_S2);

        DataString UserReq_Cross_V_S2 = new DataString();
        UserReq_Cross_V_S2.SetName("UserReq_Cross_V_S2");
        pn.PlaceList.add(UserReq_Cross_V_S2);

        DataTransfer OP_Req_Cross_N_S1 = new DataTransfer();
        OP_Req_Cross_N_S1.SetName("OP_Req_Cross_N_S1");
        OP_Req_Cross_N_S1.Value = new TransferOperation("localhost", "1082" , "UserReq_Cross_V");
        pn.PlaceList.add(OP_Req_Cross_N_S1);

        //-------------------IN---------------------------
        DataCarQueue P_LaneIn_int8_V_S2 = new DataCarQueue();
        P_LaneIn_int8_V_S2.Value.Size = 3;
        P_LaneIn_int8_V_S2.SetName("P_LaneIn_int8_V_S2");
        pn.PlaceList.add(P_LaneIn_int8_V_S2);

        DataCarQueue P_LaneIn_int9_V_S2 = new DataCarQueue();
        P_LaneIn_int9_V_S2.Value.Size = 3;
        P_LaneIn_int9_V_S2.SetName("P_LaneIn_int9_V_S2");
        pn.PlaceList.add(P_LaneIn_int9_V_S2);

        DataCar P_Lane_NiculaescuOut_V_S2 = new DataCar();
        P_Lane_NiculaescuOut_V_S2.SetName("P_Lane_NiculaescuOut_V_S2");
        pn.PlaceList.add(P_Lane_NiculaescuOut_V_S2);

        DataCar P_Lane_NiculaescuIn_V_S2 = new DataCar();
        P_Lane_NiculaescuIn_V_S2.SetName("P_Lane_NiculaescuIn_V_S2");
        pn.PlaceList.add(P_Lane_NiculaescuIn_V_S2);

        DataCarQueue P_LaneIn_int10_V_S2 = new DataCarQueue();
        P_LaneIn_int10_V_S2.Value.Size = 3;
        P_LaneIn_int10_V_S2.SetName("P_LaneIn_int10_V_S2");
        pn.PlaceList.add(P_LaneIn_int10_V_S2);

        DataCarQueue P_LaneIn_int11_V_S2 = new DataCarQueue();
        P_LaneIn_int11_V_S2.Value.Size = 3;
        P_LaneIn_int11_V_S2.SetName("P_LaneIn_int11_V_S2");
        pn.PlaceList.add(P_LaneIn_int11_V_S2);

        DataCar P_Lane_BarleaOut_V_S2 = new DataCar();
        P_Lane_BarleaOut_V_S2.SetName("P_Lane_BarleaOut_V_S2");
        pn.PlaceList.add(P_Lane_BarleaOut_V_S2);

        DataCar P_Lane_BarleaIn_V_S2 = new DataCar();
        P_Lane_BarleaIn_V_S2.SetName("P_Lane_BarleaIn_V_S2");
        pn.PlaceList.add(P_Lane_BarleaIn_V_S2);

        DataCarQueue P_LaneIn_int12_V_S2 = new DataCarQueue();
        P_LaneIn_int12_V_S2.Value.Size = 3;
        P_LaneIn_int12_V_S2.SetName("P_LaneIn_int12_V_S2");
        pn.PlaceList.add(P_LaneIn_int12_V_S2);

        DataCarQueue P_LaneIn_int13_V_S2 = new DataCarQueue();
        P_LaneIn_int13_V_S2.Value.Size = 3;
        P_LaneIn_int13_V_S2.SetName("P_LaneIn_int13_V_S2");
        pn.PlaceList.add(P_LaneIn_int13_V_S2);

        DataCar P_Lane_CarcalechiOut_V_S2 = new DataCar();
        P_Lane_CarcalechiOut_V_S2.SetName("P_Lane_CarcalechiOut_V_S2");
        pn.PlaceList.add(P_Lane_CarcalechiOut_V_S2);

        DataCar P_Lane_CarcalechiIn_V_S2 = new DataCar();
        P_Lane_CarcalechiIn_V_S2.SetName("P_Lane_CarcalechiIn_V_S2");
        pn.PlaceList.add(P_Lane_CarcalechiIn_V_S2);

        DataCarQueue P_LaneIn_int14_V_S2 = new DataCarQueue();
        P_LaneIn_int14_V_S2.Value.Size = 3;
        P_LaneIn_int14_V_S2.SetName("P_LaneIn_int14_V_S2");
        pn.PlaceList.add(P_LaneIn_int14_V_S2);

        DataCarQueue P_LaneIn_int15_V_S2 = new DataCarQueue();
        P_LaneIn_int15_V_S2.Value.Size = 3;
        P_LaneIn_int15_V_S2.SetName("P_LaneIn_int15_V_S2");
        pn.PlaceList.add(P_LaneIn_int15_V_S2);

        DataCar P_Lane_McDonaldsOut_V_S2 = new DataCar();
        P_Lane_McDonaldsOut_V_S2.SetName("P_Lane_McDonaldsOut_V_S2");
        pn.PlaceList.add(P_Lane_McDonaldsOut_V_S2);

        DataCar P_Lane_McDonaldsIn_V_S2 = new DataCar();
        P_Lane_McDonaldsIn_V_S2.SetName("P_Lane_McDonaldsIn_V_S2");
        pn.PlaceList.add(P_Lane_McDonaldsIn_V_S2);

        DataCarQueue P_LaneIn_int16_V_S2 = new DataCarQueue();
        P_LaneIn_int16_V_S2.Value.Size = 3;
        P_LaneIn_int16_V_S2.SetName("P_LaneIn_int16_V_S2");
        pn.PlaceList.add(P_LaneIn_int16_V_S2);

        DataCarQueue P_LaneIn_int17_V_S2 = new DataCarQueue();
        P_LaneIn_int17_V_S2.Value.Size = 3;
        P_LaneIn_int17_V_S2.SetName("P_LaneIn_int17_V_S2");
        pn.PlaceList.add(P_LaneIn_int17_V_S2);

        DataCarQueue P_x_Lane_V_S2 = new DataCarQueue();
        P_x_Lane_V_S2.Value.Size = 4;
        P_x_Lane_V_S2.SetName("P_x_Lane_V_S2");
        pn.PlaceList.add(P_x_Lane_V_S2);

        DataCar P_b_Lane_V_S2 = new DataCar();
        P_b_Lane_V_S2.SetName("P_b_Lane_V_S2");
        pn.PlaceList.add(P_b_Lane_V_S2);

        //-------------------OUT--------------------------
        DataCarQueue P_LaneOut_Int9_V_S2 = new DataCarQueue();
        P_LaneOut_Int9_V_S2.SetName("P_LaneOut_Int9_V_S2");
        P_LaneOut_Int9_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int9_V_S2);

        DataCarQueue P_LaneOut_Int10_V_S2 = new DataCarQueue();
        P_LaneOut_Int10_V_S2.SetName("P_LaneOut_Int10_V_S2");
        P_LaneOut_Int10_V_S2.Value.Size = 2;
        pn.PlaceList.add(P_LaneOut_Int10_V_S2);

        DataCarQueue P_BusStation_SoseauaProgresului_V_Out_S2 = new DataCarQueue();
        P_BusStation_SoseauaProgresului_V_Out_S2.SetName("P_BusStation_SoseauaProgresului_V_Out_S2");
        P_BusStation_SoseauaProgresului_V_Out_S2.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_SoseauaProgresului_V_Out_S2);

        DataCarQueue P_BusStation_SoseauaProgresului_V_S2 = new DataCarQueue();
        P_BusStation_SoseauaProgresului_V_S2.SetName("P_BusStation_SoseauaProgresului_V_S2");
        P_BusStation_SoseauaProgresului_V_S2.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_SoseauaProgresului_V_S2);

        DataCarQueue P_TramStation_SoseauaProgresului_V_Out_S2 = new DataCarQueue();
        P_TramStation_SoseauaProgresului_V_Out_S2.SetName("P_TramStation_SoseauaProgresului_V_Out_S2");
        P_TramStation_SoseauaProgresului_V_Out_S2.Value.Size = 1;
        pn.PlaceList.add(P_TramStation_SoseauaProgresului_V_Out_S2);

        DataCarQueue P_TramStation_SoseauaProgresului_V_S2 = new DataCarQueue();
        P_TramStation_SoseauaProgresului_V_S2.SetName("P_TramStation_SoseauaProgresului_V_S2");
        P_TramStation_SoseauaProgresului_V_S2.Value.Size = 1;
        pn.PlaceList.add(P_TramStation_SoseauaProgresului_V_S2);

        DataCarQueue P_LaneOut_Int11_V_S2 = new DataCarQueue();
        P_LaneOut_Int11_V_S2.SetName("P_LaneOut_Int11_V_S2");
        P_LaneOut_Int11_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int11_V_S2);

        DataCar P_LaneMarket_V_In_S2 = new DataCar();
        P_LaneMarket_V_In_S2.SetName("P_LaneMarket_V_In_S2");
        pn.PlaceList.add(P_LaneMarket_V_In_S2);

        DataCar P_LaneMarket_V_Out_S2 = new DataCar();
        P_LaneMarket_V_Out_S2.SetName("P_LaneMarket_V_Out_S2");
        pn.PlaceList.add(P_LaneMarket_V_Out_S2);

        DataCarQueue P_LaneOut_Int12_V_S2 = new DataCarQueue();
        P_LaneOut_Int12_V_S2.SetName("P_LaneOut_Int12_V_S2");
        P_LaneOut_Int12_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int12_V_S2);

        DataCarQueue P_LaneOut_Int13_V_S2 = new DataCarQueue();
        P_LaneOut_Int13_V_S2.SetName("P_LaneOut_Int13_V_S2");
        P_LaneOut_Int13_V_S2.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int13_V_S2);

        DataCarQueue P_O_Lane_V_S2 = new DataCarQueue();
        P_O_Lane_V_S2.Value.Size = 3;
        P_O_Lane_V_S2.SetName("P_O_Lane_V_S2");
        pn.PlaceList.add(P_O_Lane_V_S2);

        //------------------NORTH--------------------------
        //-------------------IN---------------------------
        DataCar P_LaneIn_N_S2 = new DataCar();
        P_LaneIn_N_S2.SetName("P_LaneIn_N_S2");
        pn.PlaceList.add(P_LaneIn_N_S2);

        DataCarQueue P_x_Lane_N_S2 = new DataCarQueue();
        P_x_Lane_N_S2.Value.Size = 3;
        P_x_Lane_N_S2.SetName("P_x_Lane_N_S2");
        pn.PlaceList.add(P_x_Lane_N_S2);

        DataCar P_b_Lane_N_S2 = new DataCar();
        P_b_Lane_N_S2.SetName("P_b_Lane_N_S2");
        pn.PlaceList.add(P_b_Lane_N_S2);

        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_N_S2 = new DataCarQueue();
        P_O_Lane_N_S2.Value.Size = 3;
        P_O_Lane_N_S2.SetName("P_O_Lane_N_S2");
        pn.PlaceList.add(P_O_Lane_N_S2);

        DataCar P_Oe_Lane_N_S2 = new DataCar();
        P_Oe_Lane_N_S2.SetName("P_Oe_Lane_N_S2");
        pn.PlaceList.add(P_Oe_Lane_N_S2);

        //------------------SOUTH--------------------------
        //-------------------IN---------------------------
        DataCar P_LaneIn_int1_S_S2 = new DataCar();
        P_LaneIn_int1_S_S2.SetName("P_LaneIn_int1_S_S2");
        pn.PlaceList.add(P_LaneIn_int1_S_S2);

        DataCarQueue P_x_Lane_S_S2 = new DataCarQueue();
        P_x_Lane_S_S2.Value.Size = 3;
        P_x_Lane_S_S1.SetName("P_x_Lane_S_S2");
        pn.PlaceList.add(P_x_Lane_S_S2);

        DataCar P_b_Lane_S_S2 = new DataCar();
        P_b_Lane_S_S2.SetName("P_b_Lane_S_S2");
        pn.PlaceList.add(P_b_Lane_S_S2);

        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_S_S2 = new DataCarQueue();
        P_O_Lane_S_S2.Value.Size = 3;
        P_O_Lane_S_S1.SetName("P_O_Lane_S_S2");
        pn.PlaceList.add(P_O_Lane_S_S2);

        DataCar P_Oe_Lane_S_S2 = new DataCar();
        P_Oe_Lane_S_S2.SetName("P_Oe_Lane_S_S2");
        pn.PlaceList.add(P_Oe_Lane_S_S2);


        //------------------EAST--------------------------
        //-------------------IN---------------------------
        DataCarQueue P_x_Lane_E_S2 = new DataCarQueue();
        P_x_Lane_E_S2.Value.Size = 3;
        P_x_Lane_E_S2.SetName("P_x_Lane_E_S2");
        pn.PlaceList.add(P_x_Lane_E_S2);

        DataCar P_b_Lane_E_S2 = new DataCar();
        P_b_Lane_E_S2.SetName("P_b_Lane_E_S2");
        pn.PlaceList.add(P_b_Lane_E_S2);

        //-------------------OUT---------------------------
        DataCarQueue P_O_Lane_E_S2 = new DataCarQueue();
        P_O_Lane_E_S2.Value.Size = 3;
        P_O_Lane_E_S2.SetName("P_O_Lane_E_S2");
        pn.PlaceList.add(P_O_Lane_E_S2);

        //-------------------INTERSECTION---------------------------
        DataCarQueue P_I_S2 = new DataCarQueue();
        P_I_S2.Value.Size = 3;
        P_I_S2.SetName("P_I_S2");
        pn.PlaceList.add(P_I_S2);

        //-------------------SEMAPHORES---------------------------
        //-------------------VEST---------------------------
        DataString P_TL_V_S2 = new DataString();
        P_TL_V_S2.SetName("P_TL_V_S2");
        pn.PlaceList.add(P_TL_V_S2);

        DataString P_PTL_V_S2 = new DataString();
        P_PTL_V_S2.SetName("P_PTL_V_S2");
        pn.PlaceList.add(P_PTL_V_S2);

        DataString UserReq_V_S2 = new DataString();
        UserReq_V_S2.SetName("UserReq_V_S2");
        pn.PlaceList.add(UserReq_V_S2);

        DataTransfer OP_Req_V_S2 = new DataTransfer();
        OP_Req_V_S2.SetName("OP_Req_V_S2");
        OP_Req_V_S2.Value = new TransferOperation("localhost", "1083" , "UserReq_V");
        pn.PlaceList.add(OP_Req_V_S2);

        //-------------------NORTH---------------------------
        DataString P_TL_N_S2 = new DataString();
        P_TL_N_S2.SetName("P_TL_N_S2");
        pn.PlaceList.add(P_TL_N_S2);

        DataString P_PTL_N_S2 = new DataString();
        P_PTL_N_S2.SetName("P_PTL_N_S2");
        pn.PlaceList.add(P_PTL_N_S2);

        DataString UserReq_N_S2 = new DataString();
        UserReq_N_S2.SetName("UserReq_N_S2");
        pn.PlaceList.add(UserReq_N_S2);

        DataTransfer OP_Req_N_S2 = new DataTransfer();
        OP_Req_N_S2.SetName("OP_Req_N_S2");
        OP_Req_N_S2.Value = new TransferOperation("localhost", "1083" , "UserReq_N");
        pn.PlaceList.add(OP_Req_N_S2);

        //-------------------SOUTH---------------------------
        DataString P_TL_S_S2 = new DataString();
        P_TL_S_S2.SetName("P_TL_S_S2");
        pn.PlaceList.add(P_TL_S_S2);

        DataString P_PTL_S_S2 = new DataString();
        P_PTL_S_S2.SetName("P_PTL_S_S2");
        pn.PlaceList.add(P_PTL_S_S2);

        DataString UserReq_S_S2 = new DataString();
        UserReq_S_S2.SetName("UserReq_S_S2");
        pn.PlaceList.add(UserReq_S_S2);

        DataTransfer OP_Req_S_S2 = new DataTransfer();
        OP_Req_S_S2.SetName("OP_Req_S_S2");
        OP_Req_S_S2.Value = new TransferOperation("localhost", "1083" , "UserReq_S");
        pn.PlaceList.add(OP_Req_S_S2);

        //-------------------EAST---------------------------
        DataString P_TL_E_S2 = new DataString();
        P_TL_E_S2.SetName("P_TL_E_S2");
        pn.PlaceList.add(P_TL_E_S2);

        DataString P_PTL_E_S2 = new DataString();
        P_PTL_E_S2.SetName("P_PTL_E_S2");
        pn.PlaceList.add(P_PTL_E_S2);

        DataString UserReq_E_S2 = new DataString();
        UserReq_E_S2.SetName("UserReq_E_S2");
        pn.PlaceList.add(UserReq_E_S2);

        DataTransfer OP_Req_E_S2 = new DataTransfer();
        OP_Req_E_S2.SetName("OP_Req_E_S2");
        OP_Req_E_S2.Value = new TransferOperation("localhost", "1083" , "UserReq_E");
        pn.PlaceList.add(OP_Req_E_S2);

        // -------------------------------------------------------------------
        // ----------------END CALEA FERENTARI SECTION 2----------------------
        // -------------------------------------------------------------------

        // -------------------------------------------------------------------
        // --------------------CALEA FERENTARI SECTION 3----------------------
        // -------------------------------------------------------------------

        //------------------VEST--------------------------
        //-------------------IN---------------------------
        DataCarQueue P_LaneIn_int1_V_S3 = new DataCarQueue();
        P_LaneIn_int1_V_S3.Value.Size = 3;
        P_LaneIn_int1_V_S3.SetName("P_LaneIn_int1_V_S3");
        pn.PlaceList.add(P_LaneIn_int1_V_S3);

        DataCarQueue P_LaneIn_int2_V_S3 = new DataCarQueue();
        P_LaneIn_int2_V_S3.Value.Size = 3;
        P_LaneIn_int2_V_S3.SetName("P_LaneIn_int2_V_S3");
        pn.PlaceList.add(P_LaneIn_int2_V_S3);

        DataCarQueue P_LaneIn_BusStationProgresului_V_S3 = new DataCarQueue();
        P_LaneIn_BusStationProgresului_V_S3.Value.Size = 2;
        P_LaneIn_BusStationProgresului_V_S3.SetName("P_LaneIn_BusStationProgresului_V_S3");
        pn.PlaceList.add(P_LaneIn_BusStationProgresului_V_S3);

        DataCarQueue P_LaneIn_BusStationProgresuluiOut_V_S3 = new DataCarQueue();
        P_LaneIn_BusStationProgresuluiOut_V_S3.Value.Size = 2;
        P_LaneIn_BusStationProgresuluiOut_V_S3.SetName("P_LaneIn_BusStationProgresuluiOut_V_S3");
        pn.PlaceList.add(P_LaneIn_BusStationProgresuluiOut_V_S3);

        DataCarQueue P_LaneIn_TramStationProgresului_V_S3 = new DataCarQueue();
        P_LaneIn_TramStationProgresului_V_S3.Value.Size = 1;
        P_LaneIn_TramStationProgresului_V_S3.SetName("P_LaneIn_TramStationProgresului_V_S3");
        pn.PlaceList.add(P_LaneIn_TramStationProgresului_V_S3);

        DataCarQueue P_LaneIn_TramStationProgresuluiOut_V_S3 = new DataCarQueue();
        P_LaneIn_TramStationProgresuluiOut_V_S3.Value.Size = 1;
        P_LaneIn_TramStationProgresuluiOut_V_S3.SetName("P_LaneIn_TramStationProgresuluiOut_V_S3");
        pn.PlaceList.add(P_LaneIn_TramStationProgresuluiOut_V_S3);

        DataCarQueue P_LaneIn_int3_V_S3 = new DataCarQueue();
        P_LaneIn_int3_V_S3.Value.Size = 3;
        P_LaneIn_int3_V_S3.SetName("P_LaneIn_int3_V_S3");
        pn.PlaceList.add(P_LaneIn_int3_V_S3);

        DataCarQueue P_LaneIn_int4_V_S3 = new DataCarQueue();
        P_LaneIn_int4_V_S3.Value.Size = 3;
        P_LaneIn_int4_V_S3.SetName("P_LaneIn_int4_V_S3");
        pn.PlaceList.add(P_LaneIn_int4_V_S3);

        DataCar P_Lane_BarbatescuVechiOut_V_S2 = new DataCar();
        P_Lane_BarbatescuVechiOut_V_S2.SetName("P_Lane_BarbatescuVechiOut_V_S2");
        pn.PlaceList.add(P_Lane_BarbatescuVechiOut_V_S2);

        DataCar P_Lane_BarbatescuVechiIn_V_S2 = new DataCar();
        P_Lane_BarbatescuVechiIn_V_S2.SetName("P_Lane_BarbatescuVechiIn_V_S2");
        pn.PlaceList.add(P_Lane_BarbatescuVechiIn_V_S2);

        DataCarQueue P_LaneIn_int5_V_S3 = new DataCarQueue();
        P_LaneIn_int5_V_S3.Value.Size = 3;
        P_LaneIn_int5_V_S3.SetName("P_LaneIn_int5_V_S3");
        pn.PlaceList.add(P_LaneIn_int5_V_S3);

        DataCar P_Lane_ParcareAURIn_V_S2 = new DataCar();
        P_Lane_ParcareAURIn_V_S2.SetName("P_Lane_ParcareAURIn_V_S2");
        pn.PlaceList.add(P_Lane_ParcareAURIn_V_S2);

        DataCar P_Lane_ParcareVistierilorOut_V_S2 = new DataCar();
        P_Lane_ParcareVistierilorOut_V_S2.SetName("P_Lane_ParcareVistierilorOut_V_S2");
        pn.PlaceList.add(P_Lane_ParcareVistierilorOut_V_S2);

        DataCarQueue P_LaneIn_TramStationChirigiu_V_S3 = new DataCarQueue();
        P_LaneIn_TramStationChirigiu_V_S3.Value.Size = 3;
        P_LaneIn_TramStationChirigiu_V_S3.SetName("P_LaneIn_TramStationChirigiu_V_S3");
        pn.PlaceList.add(P_LaneIn_TramStationChirigiu_V_S3);

        DataCarQueue P_LaneIn_TramStationChirigiuOut_V_S3 = new DataCarQueue();
        P_LaneIn_TramStationChirigiuOut_V_S3.Value.Size = 3;
        P_LaneIn_TramStationChirigiuOut_V_S3.SetName("P_LaneIn_TramStationChirigiuOut_V_S3");
        pn.PlaceList.add(P_LaneIn_TramStationChirigiuOut_V_S3);

        DataCarQueue P_LaneIn_int6_V_S3 = new DataCarQueue();
        P_LaneIn_int6_V_S3.Value.Size = 3;
        P_LaneIn_int6_V_S3.SetName("P_LaneIn_int6_V_S3");
        pn.PlaceList.add(P_LaneIn_int6_V_S3);

        DataCarQueue P_LaneIn_int7_V_S3 = new DataCarQueue();
        P_LaneIn_int7_V_S3.Value.Size = 3;
        P_LaneIn_int7_V_S3.SetName("P_LaneIn_int7_V_S3");
        pn.PlaceList.add(P_LaneIn_int7_V_S3);

        //-------------------OUT--------------------------
        DataCarQueue P_LaneOut_Int1_V_S3 = new DataCarQueue();
        P_LaneOut_Int1_V_S3.SetName("P_LaneOut_Int1_V_S3");
        P_LaneOut_Int1_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int1_V_S3);

        DataCar P_LaneDinca_V_In_S3 = new DataCar();
        P_LaneDinca_V_In_S3.SetName("P_LaneDinca_V_In_S3");
        pn.PlaceList.add(P_LaneDinca_V_In_S3);

        DataCar P_LaneDinca_V_Out_S3 = new DataCar();
        P_LaneDinca_V_Out_S3.SetName("P_LaneDinca_V_Out_S3");
        pn.PlaceList.add(P_LaneDinca_V_Out_S3);

        DataCarQueue P_LaneOut_Int2_V_S3 = new DataCarQueue();
        P_LaneOut_Int2_V_S3.SetName("P_LaneOut_Int2_V_S3");
        P_LaneOut_Int2_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int2_V_S3);

        DataCarQueue P_LaneOut_Int3_V_S3 = new DataCarQueue();
        P_LaneOut_Int3_V_S3.SetName("P_LaneOut_Int3_V_S3");
        P_LaneOut_Int3_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int3_V_S3);

        DataCar P_LaneRaditei_V_In_S3 = new DataCar();
        P_LaneRaditei_V_In_S3.SetName("P_LaneRaditei_V_In_S3");
        pn.PlaceList.add(P_LaneRaditei_V_In_S3);

        DataCarQueue P_LaneOut_Int4_V_S3 = new DataCarQueue();
        P_LaneOut_Int4_V_S3.SetName("P_LaneOut_Int4_V_S3");
        P_LaneOut_Int4_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int4_V_S3);

        DataCar P_LanePopeia_V_Out_S3 = new DataCar();
        P_LanePopeia_V_Out_S3.SetName("P_LanePopeia_V_Out_S3");
        pn.PlaceList.add(P_LanePopeia_V_Out_S3);

        DataCarQueue P_LaneOut_Int5_V_S3 = new DataCarQueue();
        P_LaneOut_Int5_V_S3.SetName("P_LaneOut_Int5_V_S3");
        P_LaneOut_Int5_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int5_V_S3);

        DataCarQueue P_BusStation_Chirigiu_V_Out_S3 = new DataCarQueue();
        P_BusStation_Chirigiu_V_Out_S3.SetName("P_BusStation_Chirigiu_V_Out_S3");
        P_BusStation_Chirigiu_V_Out_S3.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_Chirigiu_V_Out_S3);

        DataCarQueue P_BusStation_Chirigiu_V_S3 = new DataCarQueue();
        P_BusStation_Chirigiu_V_S3.SetName("P_BusStation_Chirigiu_V_S3");
        P_BusStation_Chirigiu_V_S3.Value.Size = 2;
        pn.PlaceList.add(P_BusStation_Chirigiu_V_S3);

        DataCarQueue P_LaneOut_Int6_V_S3 = new DataCarQueue();
        P_LaneOut_Int6_V_S3.Value.Size = 3;
        P_LaneOut_Int6_V_S3.SetName("P_LaneOut_Int6_V_S3");
        pn.PlaceList.add(P_LaneOut_Int6_V_S3);

        DataCarQueue P_LaneParcare_V_Out_S3 = new DataCarQueue();
        P_LaneParcare_V_Out_S3.SetName("P_LaneParcare_V_Out_S3");
        P_LaneOut_Int6_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneParcare_V_Out_S3);

        DataCarQueue P_LaneOut_Int7_V_S3 = new DataCarQueue();
        P_LaneOut_Int7_V_S3.SetName("P_LaneOut_Int7_V_S3");
        P_LaneOut_Int7_V_S3.Value.Size = 3;
        pn.PlaceList.add(P_LaneOut_Int7_V_S3);

        DataCar P_LaneAnul1821_V_Out_S3 = new DataCar();
        P_LaneAnul1821_V_Out_S3.SetName("P_LaneAnul1821_V_Out_S3");
        pn.PlaceList.add(P_LaneAnul1821_V_Out_S3);

        DataCarQueue P_LaneOut_Int8_V_S3 = new DataCarQueue();
        P_LaneOut_Int8_V_S3.SetName("P_LaneOut_Int8_V_S3");
        P_LaneOut_Int8_V_S3.Value.Size = 2;
        pn.PlaceList.add(P_LaneOut_Int8_V_S3);

        DataCar P_LaneOut_Int9_V_S3 = new DataCar();
        P_LaneOut_Int9_V_S3.SetName("P_LaneOut_Int9_V_S3");
        pn.PlaceList.add(P_LaneOut_Int9_V_S3);

        DataCarQueue P_LaneOut_TramStationChirigiu_V_S3 = new DataCarQueue();
        P_LaneOut_TramStationChirigiu_V_S3.SetName("P_LaneOut_TramStationChirigiu_V_S3");
        P_LaneOut_TramStationChirigiu_V_S3.Value.Size = 1;
        pn.PlaceList.add(P_LaneOut_TramStationChirigiu_V_S3);

        DataCarQueue P_LaneOut_TramStationChirigiuOut_V_S3 = new DataCarQueue();
        P_LaneOut_TramStationChirigiuOut_V_S3.SetName("P_LaneOut_TramStationChirigiuOut_V_S3");
        P_LaneOut_TramStationChirigiuOut_V_S3.Value.Size = 1;
        pn.PlaceList.add(P_LaneOut_TramStationChirigiuOut_V_S3);

        // -------------------------------------------------------------------
        // ----------------END CALEA FERENTARI SECTION 3----------------------
        // -------------------------------------------------------------------


        System.out.println("Lanes_Intersection_Bucharest started \n ------------------------------");
        pn.Delay = 2000;
        // pn.Start();

        PetriNetWindow frame = new PetriNetWindow(false);
        frame.petriNet = pn;
        frame.setVisible(true);
    }
}
