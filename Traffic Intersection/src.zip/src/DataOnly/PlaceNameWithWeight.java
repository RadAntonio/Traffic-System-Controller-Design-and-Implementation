package DataOnly;

public class PlaceNameWithWeight {
	public String PlaceName;
	public Float Weight;

	public PlaceNameWithWeight(String placeName, Float weight) {
		this.Weight = weight;
		this.PlaceName = placeName;
	}
}
