package Enumerations;

import java.io.Serializable;

public enum FZ implements Serializable {
	NL, NM, ZR, PM, PL, FF
}
