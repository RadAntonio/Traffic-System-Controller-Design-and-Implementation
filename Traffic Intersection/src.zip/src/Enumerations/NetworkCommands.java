package Enumerations;

public enum NetworkCommands {
	Pause, Start, Stop
}
